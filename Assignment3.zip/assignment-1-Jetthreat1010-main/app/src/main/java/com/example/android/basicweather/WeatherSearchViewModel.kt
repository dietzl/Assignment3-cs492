package com.example.android.basicweather


import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.android.basicweather.ForecastPeriod
import com.example.android.basicweather.LoadingStatus
import com.example.android.basicweather.WeatherListNewCall
import com.example.android.basicweather.WeatherService
import kotlinx.coroutines.launch

class WeatherSearchViewModel : ViewModel() {
    private val forecast = WeatherListNewCall(WeatherService.create())
    
    private val _searchResults = MutableLiveData<List<ForecastPeriod>?>(null)
    val searchResults: LiveData<List<ForecastPeriod>?> = _searchResults

    private val _loadingStatus = MutableLiveData(LoadingStatus.SUCCESS)
    val loadingStatus: LiveData<LoadingStatus> = _loadingStatus

    fun loadSearchResults(
        zip: String?,
        units: String?,
        appid: String
    ) {
        viewModelScope.launch {
            _loadingStatus.value = LoadingStatus.LOADING
            val result = forecast.loadWeatherSearch(zip, units, appid)
            _searchResults.value = result.getOrNull()
            _loadingStatus.value = when (result.isSuccess) {
                true -> LoadingStatus.SUCCESS
                false -> LoadingStatus.ERROR
            }
        }
    }
}