package com.example.android.basicweather

enum class LoadingStatus {
    LOADING, ERROR, SUCCESS
}