package com.example.android.basicweather

import android.text.TextUtils
import android.util.Log
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private var cacheZip: String?= ""
private var cacheUnits: String?= ""
private lateinit var cacheResult: WeatherListSearchResults

class WeatherListNewCall (
    private val service: WeatherService,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
    ){
    suspend fun loadWeatherSearch(
        zip: String?,
        units: String?,
        appid: String
    ): Result<List<ForecastPeriod>> =
        withContext(ioDispatcher) {
            if(cacheZip != zip && cacheUnits != units) {
                try {
                    val results = service.searchAPI(
                        buildWeatherQuery(zip),
                        units,
                        "08da51ac2b217f20da97c91b32b28213"
                    )
                    cacheZip = zip
                    cacheUnits = units
                    cacheResult = results
                    Result.success(results.list)
                } catch (e: Exception) {
                    Result.failure(e)
                }
            }
            else {
                Result.success(cacheResult.list)
            }
        }
    private fun buildWeatherQuery(zip: String?) : String {
        var newZip = ""
        if (!(TextUtils.isEmpty(zip))) {
            newZip += "$zip,us"
        }
        return newZip
    }
}