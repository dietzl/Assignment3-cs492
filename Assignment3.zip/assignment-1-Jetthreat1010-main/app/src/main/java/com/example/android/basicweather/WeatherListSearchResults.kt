package com.example.android.basicweather

data class WeatherListSearchResults (
    val list: List<ForecastPeriod>
)

