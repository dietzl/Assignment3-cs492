package com.example.android.basicweather

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

const val EXTRA_WEATHER_DETAILS = "WEATHER_DETAILS"

class WeatherDetails : AppCompatActivity() {
    private var weather: ForecastPeriod? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weather_details)

        if(intent != null && intent.hasExtra(EXTRA_WEATHER_DETAILS)) {
            weather = intent.getSerializableExtra(EXTRA_WEATHER_DETAILS) as ForecastPeriod
            val getTime = Instant.ofEpochSecond(weather!!.date)
            val dateTime = LocalDateTime.ofInstant(getTime, ZoneId.systemDefault())
            val newDateTime: DateTimeFormatter = DateTimeFormatter.ofPattern("MMM d, h:mm a")
            findViewById<TextView>(R.id.low_temp).text = weather!!.tempData.low.toString()
            findViewById<TextView>(R.id.high_temp).text = weather!!.tempData.high.toString()
            findViewById<TextView>(R.id.precip).text = weather!!.pop.toString()
            findViewById<TextView>(R.id.desc).text = weather!!.weather[0].shortDesc
            findViewById<TextView>(R.id.date_time).text = dateTime.format(newDateTime)
        }
    }
}