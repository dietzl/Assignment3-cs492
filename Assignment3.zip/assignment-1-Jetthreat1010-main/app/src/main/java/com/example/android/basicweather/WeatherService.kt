package com.example.android.basicweather

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import retrofit2.Retrofit
import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.converter.moshi.MoshiConverterFactory

interface WeatherService {
    @GET("forecast")
    suspend fun searchAPI(
        @Query("zip") zip: String?,
        @Query("units") units: String?,
        @Query("appid") appid: String
    ) : WeatherListSearchResults

    companion object {
        private const val BASE_URL = "https://api.openweathermap.org/data/2.5/"
        fun create() : WeatherService {
            val moshi = Moshi.Builder()
                .addLast(KotlinJsonAdapterFactory())
                .build()
            val retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
            return retrofit.create(WeatherService::class.java)
        }
    }
}