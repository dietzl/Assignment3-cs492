package com.example.android.basicweather

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.activity.viewModels
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.Volley
import com.squareup.moshi.Moshi
import com.squareup.moshi.JsonAdapter
import com.android.volley.toolbox.StringRequest
import com.google.android.material.progressindicator.CircularProgressIndicator
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

class MainActivity : AppCompatActivity() {
    private val tag = "MainActivity"

    private val weatherAdapter = WeatherListAdapter(::onWeatherDetailsClick)

    private val viewModel: WeatherSearchViewModel by viewModels()

    private lateinit var requestQueue: RequestQueue
    private lateinit var weatherListRV: RecyclerView
    private lateinit var weatherErrorTV: TextView
    private lateinit var loadingIndicator: CircularProgressIndicator

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        requestQueue = Volley.newRequestQueue(this)

        weatherErrorTV = findViewById(R.id.weather_error)
        loadingIndicator = findViewById(R.id.loading_indicator)

        weatherListRV = findViewById<RecyclerView>(R.id.rv_card_list)
        weatherListRV.layoutManager = LinearLayoutManager(this)
        weatherListRV.setHasFixedSize(true)

        weatherListRV.adapter = weatherAdapter

        viewModel.searchResults.observe(this) { searchResults ->
            weatherAdapter.updateWeatherList(searchResults)
        }

        viewModel.loadingStatus.observe(this) { loadingStatus ->
            when (loadingStatus) {
                LoadingStatus.LOADING -> {
                    loadingIndicator.visibility = View.VISIBLE
                    weatherListRV.visibility = View.INVISIBLE
                    weatherErrorTV.visibility = View.INVISIBLE
                }
                LoadingStatus.ERROR -> {
                    loadingIndicator.visibility = View.INVISIBLE
                    weatherListRV.visibility = View.INVISIBLE
                    weatherErrorTV.visibility = View.VISIBLE
                }
                else -> {
                    loadingIndicator.visibility = View.INVISIBLE
                    weatherListRV.visibility = View.VISIBLE
                    weatherErrorTV.visibility = View.INVISIBLE
                }
            }
        }

        val sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this)

        val user = sharedPrefs.getString(
            getString(R.string.pref_user_key),
            null
        )

        val units = sharedPrefs.getString(
            getString(R.string.units_key),
            null
        )


        viewModel.loadSearchResults(user,units,"08da51ac2b217f20da97c91b32b28213")
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                val intent = Intent(this, SettingsActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.activity_main, menu)
        return true
    }

    fun doWeatherSearch() {
        val url = "https://api.openweathermap.org/data/2.5/forecast?zip=97333,us&units=imperial&appid=08da51ac2b217f20da97c91b32b28213"

        val moshi = Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()
        val jsonAdapter: JsonAdapter<WeatherListSearchResults> =
            moshi.adapter(WeatherListSearchResults::class.java)
        val req = StringRequest(
            Request.Method.GET,
            url,
            {
                val results = jsonAdapter.fromJson(it)
                Log.d(tag, results.toString())
                weatherAdapter.updateWeatherList(results?.list)
                loadingIndicator.visibility = View.INVISIBLE
                weatherListRV.visibility = View.VISIBLE
            },
            {
                Log.d(tag, "Error fetching from $url: ${it.message}")
                loadingIndicator.visibility = View.INVISIBLE
                weatherErrorTV.visibility = View.VISIBLE
            }
        )
        loadingIndicator.visibility = View.VISIBLE
        weatherListRV.visibility = View.INVISIBLE
        weatherErrorTV.visibility = View.INVISIBLE
        requestQueue.add(req)
    }

    private fun onWeatherDetailsClick(forecastPeriod: ForecastPeriod){
        val intent = Intent(this, WeatherDetails::class.java)
        intent.putExtra(EXTRA_WEATHER_DETAILS, forecastPeriod)
        startActivity(intent)
    }


}