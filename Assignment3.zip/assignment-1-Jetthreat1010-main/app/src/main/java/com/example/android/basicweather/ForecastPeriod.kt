package com.example.android.basicweather

import com.squareup.moshi.Json
import java.io.Serializable

data class ForecastPeriod(
    @Json(name = "dt") val date: Long,
    @Json(name = "main") val tempData: ForecastTemp,
    @Json(name = "weather") val weather: List<ForecastWeather>,
    @Json(name = "pop") val pop: Float
) : Serializable

data class ForecastTemp (
    @Json(name = "temp_min") val low: Float,
    @Json(name = "temp_max") val high: Float,
) : Serializable

data class ForecastWeather (
    @Json(name = "description") val shortDesc: String,
) : Serializable


